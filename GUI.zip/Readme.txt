1. main_file is the main the file containing python code.
2. all the python libs requirements are in the requirements.txt file make sure you install them.
3. go to cmd, activate your env and then cd into your folder.
4. after that do, python main_file.py